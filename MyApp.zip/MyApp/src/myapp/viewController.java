/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myapp;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
/**
 *
 * @author fadikhan
 */
public class viewController implements Initializable {
    
     @FXML
    private TextField newText;

    @FXML
    private TextField newText1;

    @FXML
    private Label label_1;

    @FXML
    void showResult(ActionEvent event) {
        double valOne=Double.parseDouble(newText.getText());
        double valTwo=Double.parseDouble(newText1.getText());
        double sum=valOne+valTwo;
        label_1.setText("The Answer is :\t"+ sum);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
